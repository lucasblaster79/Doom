package com.doomport;

import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.view.WindowManager;

import org.libsdl.app.SDLActivity;

/** Actividad del juego: SDL2 + Chocolate Doom, en pantalla completa y con controles tactiles. */
public class DoomActivity extends SDLActivity {

    public static final String EXTRA_IWAD = "iwad";

    @Override
    protected String[] getLibraries() {
        // libSDL2_mixer.so se carga como dependencia de libmain.so
        return new String[] { "SDL2", "main" };
    }

    @Override
    protected String[] getArguments() {
        String iwad = getIntent().getStringExtra(EXTRA_IWAD);
        if (iwad == null) return new String[0];
        return new String[] { "-iwad", iwad };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Usar tambien la zona del notch / camara perforada
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        if (mLayout != null) {
            mLayout.addView(new TouchControlsView(this),
                    new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT));
        }
    }

    /** El boton "atras" abre/cierra el menu de Doom (ESC) en lugar de cerrar la app. */
    @Override
    public void onBackPressed() {
        SDLActivity.onNativeKeyDown(KeyEvent.KEYCODE_ESCAPE);
        SDLActivity.onNativeKeyUp(KeyEvent.KEYCODE_ESCAPE);
    }
}
