package com.doomport;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.database.Cursor;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Pantalla inicial. El APK NO incluye ningun WAD: el usuario elige su propio
 * doom.wad / doom2.wad / doom1.wad (shareware), que se copia al almacenamiento
 * interno de la app.
 */
public class LauncherActivity extends Activity {

    private static final int REQ_PICK_WAD = 1001;
    private static final String PREFS = "doom";
    private static final String PREF_IWAD = "iwad";

    private TextView status;
    private Button playButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.BLACK);
        int pad = dp(24);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("DOOM");
        title.setTextColor(Color.rgb(200, 30, 20));
        title.setTextSize(48);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(15);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(12), 0, dp(20));
        root.addView(status);

        playButton = new Button(this);
        playButton.setText("Jugar");
        playButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startGame(); }
        });
        root.addView(playButton, new LinearLayout.LayoutParams(dp(260), LinearLayout.LayoutParams.WRAP_CONTENT));

        Button pick = new Button(this);
        pick.setText("Elegir archivo WAD");
        pick.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { pickWad(); }
        });
        root.addView(pick, new LinearLayout.LayoutParams(dp(260), LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    private void refresh() {
        File wad = currentWad();
        if (wad != null) {
            status.setText("WAD: " + wad.getName());
            playButton.setEnabled(true);
        } else {
            status.setText("Elegi tu archivo WAD (doom.wad, doom2.wad o doom1.wad)\n"
                    + "para poder jugar. El juego no incluye ningun WAD.");
            playButton.setEnabled(false);
        }
    }

    private File wadDir() {
        File dir = new File(getFilesDir(), "wads");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private File currentWad() {
        String name = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_IWAD, null);
        if (name == null) return null;
        File f = new File(wadDir(), name);
        return f.isFile() ? f : null;
    }

    private void pickWad() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_PICK_WAD);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK_WAD || resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }
        final Uri uri = data.getData();
        status.setText("Copiando WAD...");
        playButton.setEnabled(false);
        new Thread(new Runnable() {
            @Override public void run() {
                final String err = importWad(uri);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (err != null) {
                            Toast.makeText(LauncherActivity.this, err, Toast.LENGTH_LONG).show();
                        }
                        refresh();
                    }
                });
            }
        }).start();
    }

    /** Copia el WAD elegido a filesDir/wads. Devuelve null si salio bien, o un mensaje de error. */
    private String importWad(Uri uri) {
        String name = displayName(uri);
        if (name == null || name.length() == 0) name = "iwad.wad";
        name = name.replaceAll("[^A-Za-z0-9._-]", "_");
        File tmp = new File(wadDir(), name + ".part");
        InputStream in = null;
        OutputStream out = null;
        try {
            in = getContentResolver().openInputStream(uri);
            if (in == null) return "No se pudo abrir el archivo";
            out = new FileOutputStream(tmp);
            byte[] buf = new byte[1 << 16];
            int n;
            boolean first = true;
            while ((n = in.read(buf)) > 0) {
                if (first) {
                    first = false;
                    if (n < 12 || buf[0] != 'I' || buf[1] != 'W' || buf[2] != 'A' || buf[3] != 'D') {
                        out.close(); out = null;
                        tmp.delete();
                        return "Ese archivo no es un IWAD de Doom valido";
                    }
                }
                out.write(buf, 0, n);
            }
            out.close(); out = null;
            File dest = new File(wadDir(), name);
            if (dest.exists()) dest.delete();
            if (!tmp.renameTo(dest)) return "No se pudo guardar el WAD";
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_IWAD, name).apply();
            return null;
        } catch (IOException e) {
            tmp.delete();
            return "Error al copiar el WAD: " + e.getMessage();
        } finally {
            try { if (in != null) in.close(); } catch (IOException ignored) {}
            try { if (out != null) out.close(); } catch (IOException ignored) {}
        }
    }

    private String displayName(Uri uri) {
        Cursor c = null;
        try {
            c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) return c.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return uri.getLastPathSegment();
    }

    private void startGame() {
        File wad = currentWad();
        if (wad == null) return;
        writeDefaultConfigs();
        Intent i = new Intent(this, DoomActivity.class);
        i.putExtra(DoomActivity.EXTRA_IWAD, wad.getAbsolutePath());
        startActivity(i);
    }

    /**
     * Configuracion inicial de Chocolate Doom (solo si todavia no existe):
     * pantalla completa, sin pantalla ENDOOM al salir (en tactil quedaria trabada),
     * correr siempre, y teclas '[' y ']' para cambiar de arma desde los botones tactiles.
     */
    private void writeDefaultConfigs() {
        String cfg =
                "fullscreen 1\n" +
                "aspect_ratio_correct 1\n" +
                "integer_scaling 0\n" +
                "stretch_to_fill 1\n" +
                "show_endoom 0\n" +
                "always_run 1\n" +
                "key_prevweapon 91\n" +
                "key_nextweapon 93\n";
        String[] names = { "default.cfg", "chocolate-doom.cfg" };
        for (String n : names) {
            File f = new File(getFilesDir(), n);
            if (f.exists()) continue;
            try {
                FileOutputStream o = new FileOutputStream(f);
                o.write(cfg.getBytes("UTF-8"));
                o.close();
            } catch (IOException ignored) {
            }
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
